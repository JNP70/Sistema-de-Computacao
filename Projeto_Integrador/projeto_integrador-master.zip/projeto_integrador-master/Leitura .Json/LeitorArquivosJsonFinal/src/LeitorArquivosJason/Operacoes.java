/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LeitorArquivosJason;

/**
 *
 * @author bcnet
 */
//import Conexao.Conexao;//
//import entidades.QuestionarioRespostas;
import java.awt.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author bcnet
 */
public class Operacoes {
    
    private Connection con;
    
    
    public Operacoes() 
    {
        //this.con = Conexao.Conectar();
    }
    
    public boolean inserirTempoScore(int ponto,double tempo, int id) 
    {
        this.con = Conexao.Conectar();
        //System.out.println(con);
        String query = "INSERT INTO dados_jogos(ponto_jogo,tempo_jogo,id_jogo)VALUES(?,?,?)";
        //this.con = Conexao.Conectar();
        
        try 
        {
            PreparedStatement stmt = con.prepareStatement(query);
            
            stmt.setInt(1, ponto);
            stmt.setDouble(2, tempo);
            stmt.setInt(3, id);
            
            
            
            stmt.executeUpdate();
            stmt.close();
            
            //System.out.println("Dados inseridos com sucesso");
            return true;
            
        } 
        catch (SQLException ex) 
        {
            System.out.println("Erro: " + ex.getMessage());
            return false;
            
        }
        finally
        {
            
            Conexao.Desconectar();
        }
        
        
    }
    public ArrayList<Integer> buscarRespostasQuestionario(String coluna, int id_jogo)
    {
        this.con = Conexao.Conectar();
        ResultSet rs = null;
        ArrayList<Integer>quest = new ArrayList<>();
        //quest = null;
        //String x = "perguntas";
        String query = "select * from perguntas where id_jogo = ?";
        try 
        {
            PreparedStatement stmt = con.prepareStatement(query);
            //stmt.setString(1, x);
            stmt.setInt(1, id_jogo);
            //stmt.setString(1, coluna);
            rs = stmt.executeQuery();
            //rs.first();
            
            
            while(rs.next())
            {
               //QuestionarioRespostas q = new QuestionarioRespostas();
               //q.setNota1(rs.getInt(1));
                //System.out.println(rs.getInt(coluna));
               //q.setNota2(rs.getInt(2));
               //q.setNota3(rs.getInt(3));
               //q.setNota4(rs.getInt(4));
               //q.setNota5(rs.getInt(5));
               quest.add(rs.getInt(coluna));
            }
           
            rs.close();
            stmt.close();
            //System.out.println(quest);
            return quest;
            //quest;
            
        } 
        catch (SQLException ex) 
        {
            
            return quest;
        }
        finally
        {
            Conexao.Desconectar();
        }
        
        
    }
    
    public ArrayList<Double> buscarTempoJogos(String coluna, int id_jogo)
    {
        this.con = Conexao.Conectar();
        ResultSet rs = null;
        ArrayList<Double>quest = new ArrayList<>();
        //quest = null;
        //String x = "perguntas";
        String query = "select * from dados_jogos where id_jogo = ?";
        try 
        {
            PreparedStatement stmt = con.prepareStatement(query);
            //stmt.setString(1, x);
            stmt.setInt(1, id_jogo);
            //stmt.setString(1, coluna);
            rs = stmt.executeQuery();
            //rs.first();
            
            
            while(rs.next())
            {
               //QuestionarioRespostas q = new QuestionarioRespostas();
               //q.setNota1(rs.getInt(1));
                //System.out.println(rs.getString(coluna));
               //q.setNota2(rs.getInt(2));
               //q.setNota3(rs.getInt(3));
               //q.setNota4(rs.getInt(4));
               //q.setNota5(rs.getInt(5));
               quest.add(rs.getDouble(coluna));
            }
           
            rs.close();
            stmt.close();
            //System.out.println(quest);
            return quest;
            //quest;
            
        } 
        catch (SQLException ex) 
        {
            System.out.println("Erro: " + ex.getMessage());

            return quest;
        }
        finally
        {
            Conexao.Desconectar();
        }
        
        
    }
    
    
    public ArrayList<String> buscarNomeJogos()
    {
        this.con = Conexao.Conectar();
        ResultSet rs = null;
        ArrayList<String>jogos = new ArrayList<>();
        String query = "select * from jogos" ;
        
        try 
        {
            PreparedStatement stmt = con.prepareStatement(query);
            //stmt.setString(1, coluna);
            
            rs = stmt.executeQuery();
            while(rs.next())
            {
               //QuestionarioRespostas q = new QuestionarioRespostas();
               //q.setNota1(rs.getInt(1));
                //System.out.println(rs.getString("nome"));
               //q.setNota2(rs.getInt(2));
               //q.setNota3(rs.getInt(3));
               //q.setNota4(rs.getInt(4));
               //q.setNota5(rs.getInt(5));
               jogos.add(rs.getString("nome"));
            }
            
            stmt.close();
            //System.out.println(jogos);
            return jogos;            
        } 
        catch (SQLException ex) 
        {
            System.out.println("Erro: " + ex.getMessage());

            return jogos;
        }
        finally
        {
            Conexao.Desconectar();
        }
    }
    
    public int buscarIdJogos(String nome)
    {   
        this.con = Conexao.Conectar();
        ResultSet rs = null;
        //ArrayList<String>jogos = new ArrayList<>();
        String query = "select id_jogo from jogos where nome = ?" ;
        int id = 0;
        try 
        {   PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, nome);
            
            rs = stmt.executeQuery();
            while(rs.next())
            {
               //QuestionarioRespostas q = new QuestionarioRespostas();
               //q.setNota1(rs.getInt(1));
                //System.out.println(rs.getInt("id_jogo"));
               //q.setNota2(rs.getInt(2));
               //q.setNota3(rs.getInt(3));
               //q.setNota4(rs.getInt(4));
               //q.setNota5(rs.getInt(5));
               //jogos.add(rs.getString("nome"));
               id = rs.getInt("id_jogo");
            }
            
            
            
            stmt.close();
            //System.out.println(id);
            //System.out.println(id);
            return id;            
        } 
        catch (SQLException ex) 
        {
            System.out.println("Erro: " + ex.getMessage());
            return id;
        }
        finally
        {
            Conexao.Desconectar();
        }
    }
    
    public ArrayList<Integer> buscarPontuacaoJogos(int id_jogo)
    {
        this.con = Conexao.Conectar();
        ResultSet rs = null;
        ArrayList<Integer>quest = new ArrayList<>();
        //quest = null;
        //String x = "perguntas";
        String query = "select ponto_jogo from dados_jogos where id_jogo = ?";
        try 
        {
            PreparedStatement stmt = con.prepareStatement(query);
            //stmt.setString(1, x);
            stmt.setInt(1, id_jogo);
            //stmt.setString(1, coluna);
            rs = stmt.executeQuery();
            //rs.first();
            
            
            while(rs.next())
            {
               //QuestionarioRespostas q = new QuestionarioRespostas();
               //q.setNota1(rs.getInt(1));
                //System.out.println(rs.getInt("ponto_jogo"));
               //q.setNota2(rs.getInt(2));
               //q.setNota3(rs.getInt(3));
               //q.setNota4(rs.getInt(4));
               //q.setNota5(rs.getInt(5));
               quest.add(rs.getInt("ponto_jogo"));
            }
           
            rs.close();
            stmt.close();
            //System.out.println(quest);
            return quest;
            //quest;
            
        } 
        catch (SQLException ex) 
        {
            System.out.println("Erro: " + ex.getMessage());
            return quest;
        }
        finally
        {
            Conexao.Desconectar();
        }
        
        
    }
    public Integer Frequencia(int id_jogo,int min,int max)
    {
        this.con = Conexao.Conectar();
        ResultSet rs = null;
        int frequencia = 0;
        //quest = null;
        //String x = "perguntas";
        String query = "select count(ponto_jogo)as frequencia from dados_jogos where id_jogo = ? AND ponto_jogo BETWEEN ? AND ?";        
        try 
        {
            PreparedStatement stmt = con.prepareStatement(query);
            //stmt.setString(1, x);
            stmt.setInt(1, id_jogo);
            stmt.setInt(2, min);
            stmt.setInt(3, max);
            //stmt.setString(1, coluna);
            rs = stmt.executeQuery();
            //rs.first();
            
            
            while(rs.next())
            {
               //QuestionarioRespostas q = new QuestionarioRespostas();
               //q.setNota1(rs.getInt(1));
                //System.out.println(rs.getInt("ponto_jogo"));
               //q.setNota2(rs.getInt(2));
               //q.setNota3(rs.getInt(3));
               //q.setNota4(rs.getInt(4));
               //q.setNota5(rs.getInt(5));
               frequencia = rs.getInt("frequencia");
            }
           
            rs.close();
            stmt.close();
            //System.out.println(quest);
            return frequencia;
            //quest;
            
        } 
        catch (SQLException ex) 
        {
            System.out.println("Erro: " + ex.getMessage());
            return frequencia;
        }
        finally
        {
            Conexao.Desconectar();
        }     
    }
    
    public Integer FrequenciaTempo(int id_jogo,double min,double max)
    {
        this.con = Conexao.Conectar();
        ResultSet rs = null;
        int frequenciaTemp = 0;
        //quest = null;
        //String x = "perguntas";
        String query = "select count(tempo_jogo)as frequencia from dados_jogos where id_jogo = ? AND tempo_jogo >= ? AND tempo_jogo < ?";        
        try 
        {
            PreparedStatement stmt = con.prepareStatement(query);
            //stmt.setString(1, x);
            stmt.setInt(1, id_jogo);
            stmt.setDouble(2, min);
            stmt.setDouble(3, max);
            //stmt.setString(1, coluna);
            rs = stmt.executeQuery();
            //rs.first();
            
            
            while(rs.next())
            {
               //QuestionarioRespostas q = new QuestionarioRespostas();
               //q.setNota1(rs.getInt(1));
                //System.out.println(rs.getInt("ponto_jogo"));
               //q.setNota2(rs.getInt(2));
               //q.setNota3(rs.getInt(3));
               //q.setNota4(rs.getInt(4));
               //q.setNota5(rs.getInt(5));
               frequenciaTemp = rs.getInt("frequencia");
            }
           
            rs.close();
            stmt.close();
            //System.out.println(quest);
            return frequenciaTemp;
            //quest;
            
        } 
        catch (SQLException ex) 
        {
            System.out.println("Erro: " + ex.getMessage());
            return frequenciaTemp;
        }
        finally
        {
            Conexao.Desconectar();
        }     
    } 
}

