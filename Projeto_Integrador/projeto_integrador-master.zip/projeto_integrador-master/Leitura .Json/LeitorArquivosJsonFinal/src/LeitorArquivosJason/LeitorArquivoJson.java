/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LeitorArquivosJason;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import javax.swing.JOptionPane;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 *
 * @author Aluno
 */
public class LeitorArquivoJson {
    
        //private String diretorio = "B:\\Documentos\\Teste";

    
    public LeitorArquivoJson()
    {
        
        
    }
    public File[] GerarListaArquivos(String diretorio)
    {
        File file = new File(diretorio);
	File afile[] = file.listFiles();
	//int i = 0;
	//for (int j = afile.length; i < j; i++) 
        //{
            //File arquivos = afile[i];
         //   System.out.println(arquivos.getName());

        //}
        return afile;
    }
    public boolean verificarListaArq(String diretorio)
    {
        if(GerarListaArquivos(diretorio).length > 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    public void LeituraArquivos(String diretorio) 
    {
        //JSONObject jsonObject;
        //Cria o parse de tratamento
        //JSONParser parser = new JSONParser();
        //Variaveis que irao armazenar os dados do arquivo JSON
       // double tempo;
       // int score;
       // Operacoes op = new Operacoes();
        if(verificarListaArq(diretorio) == true)
        {
 
            try {
                for(int i = 0; i < GerarListaArquivos(diretorio).length; i++)
                {
                    String arquivo = diretorio+"\\"+GerarListaArquivos(diretorio)[i].getName();
                    //System.out.println(arquivo);
                    JSONObject jsonObject;
                    //Cria o parse de tratamento
                    JSONParser parser = new JSONParser();
                    //Variaveis que irao armazenar os dados do arquivo JSON
                    double tempo;
                    int score;
                    Operacoes op = new Operacoes();
                    //Salva no objeto JSONObject o que o parse tratou do arquivo
                    jsonObject = (JSONObject) parser.parse(new FileReader(arquivo));

                    //Salva nas variaveis os dados retirados do arquivo
                    score = Integer.parseInt(jsonObject.get("TotalDeaths").toString());
                    tempo = Double.parseDouble(jsonObject.get("TotalTime").toString());
                    tempo = Math.round(tempo);
                    //BigDecimal v = new BigDecimal(tempo).setScale(2, RoundingMode.HALF_DOWN);

                    op.inserirTempoScore(score, tempo, 1);

                    //System.out.printf("Score: %s\nTempo: %s\n",score, tempo);
                }
                JOptionPane.showMessageDialog(null,"Varredura terminada");
                
            } 
            //Trata as exceptions que podem ser lançadas no decorrer do processo
            catch (FileNotFoundException e) 
            {
                e.printStackTrace();
            } 
            catch (IOException e) 
            {
                e.printStackTrace();
            } 
            catch (ParseException e) 
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            catch (NullPointerException e) 
            {
                // TODO Auto-generated catch block
                JOptionPane.showMessageDialog(null,"Programa encerrado!!!");
                //e.printStackTrace();
            }
            
        }
        else
        {
            JOptionPane.showMessageDialog(null,"O diretório esta vazio!!!");
        }
    }
    
    
}

                
    
            


	
	



/**
 * @param args
 */

    

