
package prota.modelos;

public class OutrosServicos extends Produto{

    private static double precob = 70;
    private static double precoa = 50;
    private static double precot = 85.49;
    
    public OutrosServicos() {
    }

    public OutrosServicos(String nome, int codigo, int quantidade) {
        super(nome, codigo, quantidade);
    }

    
    
    public double Baleacemento(double desconto){
        return precob = precob - desconto;
    }
    
    public double Alinhamento(double desconto){
        return precoa = precoa - desconto;
    }
    
    public double TrocaOleo(double desconto){
        return precot - desconto;
    
    }
    
}
