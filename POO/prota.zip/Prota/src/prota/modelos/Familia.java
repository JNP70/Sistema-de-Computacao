
package prota.modelos;

/**
 *
 * @author usuario
 */
public class Familia extends Cliente{
    
    protected double desconto;

    public Familia() {
    }

    public Familia(double desconto, String nome, String cpf, String servico, int codigo) {
        super(nome, cpf, servico, codigo);
        this.desconto = desconto;
    }
    
    public String DaDesconto(){
        return "Dá desconto sim, e parcela o quanto precisar";
    }
    
    
    
}
