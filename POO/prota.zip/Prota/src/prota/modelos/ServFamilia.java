
package prota.modelos;

/**
 *
 * @author usuario
 */
public class ServFamilia extends Produto{
    
    protected String gratis;
    private static double precob = 70;
    private static double precoa = 50;
    private static double precot = 85.49;
    

    public ServFamilia() {
    }

    public ServFamilia(String gratis, String nome, int codigo, int quantidade) {
        super(nome, codigo, quantidade);
        this.gratis = gratis;
    }

    
    
    public double Baleacemento(double desconto){
        return precob = precob - desconto;
    }
    
    public String Alinhamento(){
        return gratis = "Nada, Para Familia o alinhamento é gratis.";
    }
    
    public double TrocaOleo(double desconto){
        return precot - desconto;
    
    }
    
}
