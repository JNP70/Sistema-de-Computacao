
package prota.modelos;

public class Cliente {
    
    protected String nome;
    protected String cpf;
    protected String servico;
    protected int codigo;

    public Cliente() {
    }

    public Cliente(String nome, String cpf, String servico, int codigo) {
        this.nome = nome;
        this.cpf = cpf;
        this.servico = servico;
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        if (cpf.length() == 14) {
            this.cpf = cpf;
        } else {
            System.out.println("Venda irregular!!!");
        }
    }

    public String getServico() {
        return servico;
    }

    public void setServico(String servico) {
        this.servico = servico;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    @Override
    public String toString() {
        return "Cliente{" + "nome=" + nome + ", cpf=" + cpf + ", servico=" + servico + ", codigo=" + codigo + '}';
    }
    
    public String DaDesconto(){
        return "Desconto, Só para pagamento a vista";
    }
    
}
