
package prota.modelos;


public class Pneu extends Produto {
    
    private double valor;
    

    public Pneu() {
    }

    public Pneu(double descontof, String nome, int codigo, int quantidade) {
        super(nome, codigo, quantidade);
        this.valor = valor;
    }

     public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    
    
    public double comprarJogoa(){
        return valor*quantidade;
    }
    
    public double comprarEstepe(){
        return valor - (valor/2);
    }
}
