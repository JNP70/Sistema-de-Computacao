
package prota.modelos;

public interface InterfaceProta {
   
    public abstract String getNome();
    public abstract String getCpf();
    public abstract String getServico();
    public abstract int getCodigo();
    public abstract int getQuantidade();
    public abstract double getDesconto();
    
    public abstract void setNome();
    public abstract void setCpf();
    public abstract void setServico();
    public abstract void setCodigo();
    public abstract void setQuantidade();
    public abstract void setDesconto();
    
    public abstract String toString();
    public abstract void Balanceamento();
    public abstract void Alinhamento();
    public abstract void TrocaOleo();
    public abstract void ComprarJogoa();
    public abstract void ComprarEstepe();
    
}
