
package prota;
import prota.modelos.Cliente;
import prota.modelos.Familia;
import prota.modelos.Produto;
import prota.modelos.Pneu;
import prota.modelos.OutrosServicos;
import prota.modelos.ServFamilia;

public class Prota {


    public static void main(String[] args) {
        
        Cliente pati = new Cliente();
        Pneu adi = new Pneu();
        OutrosServicos serv = new OutrosServicos();
        
        pati.setNome("tais");
        pati.setCpf("987.642.453.10");
        pati.setCodigo(21);
        pati.DaDesconto();
                
        adi.setNome("Pirelli");
        adi.setCodigo(100);
        adi.setQuantidade(2);
        adi.setValor(225.00);
        adi.comprarJogoa();
        
        Familia poly = new Familia();
        Pneu pol =new Pneu();
        ServFamilia polly = new ServFamilia();
        
        poly.setNome("pollynne");
        poly.setCpf("123456789.45");
        poly.setCodigo(121);
        poly.DaDesconto();
        pol.setNome("Bridgestone");
        pol.setCodigo(110);
        pol.setQuantidade(4);
        pol.setValor(200);
        pol.comprarJogoa();
        
        System.out.println(pati.toString());
        System.out.println("O cliente "+pati.getNome()+ " comprou: "+adi.getNome()+"\n" + adi.getQuantidade()+"\n" + adi.getValor());
        System.out.println("A cliente "+ pati.getNome()+" pagou por servicos: " + serv.Alinhamento(0)+ "\n" + pati.DaDesconto());
    
        System.out.println("O cliente é: "+poly.getNome()+ "Comprou: "+ pol.getNome() + "O valor é: " +pol.comprarJogoa());
        System.out.println("A cliente "+ poly.getNome()+" Efetuou o serviço: "+polly.Alinhamento()+ "\n" + poly.DaDesconto());
    
    }
    
}
