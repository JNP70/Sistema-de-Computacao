package revisaon2;

public class Cliente {
    private int numero_cliente;
    private String nome;

    public Cliente(int numero_cliente, String nome) {
        this.numero_cliente = numero_cliente;
        this.nome = nome;
    }
    
}
